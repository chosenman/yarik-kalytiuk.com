
var ball   = document.querySelector('.ball');
var garden = document.querySelector('.garden');
var output = document.querySelector('.output');




var maxX = $('body').innerWidth()  - $('.ball').innerWidth();
var maxY = $('body').innerWidth() - $('.garden').innerHeight();

function handleOrientation(event) {
    var x = event.beta;  // In degree in the range [-180,180]
    var y = event.gamma; // In degree in the range [-90,90]

    output.innerHTML  = "beta : " + x + "\n";
    output.innerHTML += "gamma: " + y + "\n";

    // Because we don't want to have the device upside down
    // We constrain the x value to the range [-90,90]
    if (x >  90) { x =  90};
    if (x < -90) { x = -90};

    // To make computation easier we shift the range of
    // x and y to [0,180]
    x += 90;
    y += 90;

    // 10 is half the size of the ball
    // It center the positioning point to the center of the ball
    ball.style.top  = (maxX*x/180 - ($('.ball').innerWidth()/2) ) + "px";
    ball.style.left = (maxY*y/180 - ($('.ball').innerWidth()) ) + "px";
}

window.addEventListener('deviceorientation', handleOrientation);


// Touch stuff:

var clientWidth = $( window ).width();

// $('#pageone').css('width', clientWidth);
// $('.garden').css('width', clientWidth);
// $('.ball').css('left', clientWidth/2);

$( document ).ready(function() {
    $("#pageone").on("tap",function(){
        // $(this).hide();
        $('.outputTouched').prepend("- ")
    });
});